/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import Interface.InterfaceRanking;
import TADS.ListaDinamica;

/**
 *
 * @author dario
 * @param <J>
 */
public class RankingInfantil<J extends Jogador> implements InterfaceRanking{
    
    private final ListaDinamica<PontuacaoInfantil> adapteeInfantil;
    private final int numPosicoes;
    
    public RankingInfantil(){
    adapteeInfantil = new ListaDinamica<>();
    this.numPosicoes=10;
    }
    
    /**
     * 
     * @return 
     */
    @Override
    public int size() {
        return adapteeInfantil.size();
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isEmpty() {
        return adapteeInfantil.isEmpty();
    }

    /**
     * 
     * @param idx
     * @param elemento 
     */
    @Override
    public void adicionar(int idx, Object elemento) {
        adapteeInfantil.add(idx, (PontuacaoInfantil) elemento);
    }
    
    /**
     * 
     * @param idx
     */
    @Override
    public void remover (int idx){
    adapteeInfantil.remove(idx);
    }
    
}
