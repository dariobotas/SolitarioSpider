/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import Interface.InterfaceCarta;
import pt.ips.pa.model.tads.ModeloCarta.CorCarta;
import pt.ips.pa.model.tads.ModeloCarta.FiguraCarta;
import pt.ips.pa.model.tads.ModeloCarta.NaipeCarta;
import javax.swing.JComponent;

/**
 *
 * @author AnTRaX
 */
public abstract class Carta extends JComponent implements InterfaceCarta{
    private FiguraCarta figura;
    private CorCarta cor;

    /**
     * Construtor da Carta 
     * @param figura 
     */
    public Carta(FiguraCarta figura){
    this.figura = figura;
    }
    
    /**
     * Método que retorna a figura da carta
     * @return figura
     */
    @Override
    public FiguraCarta getFigura() {
        return this.figura;
    }

    /**
     * Método que altera a figura da carta
     * @param figura
     */
    @Override
    public void setFigura(FiguraCarta figura){
        this.figura = figura;
    }

    /**
     * Método que obtém a cor da carta
     * @return cor
     */
    @Override
    public CorCarta getCor(){
    return this.cor;
    }

    /**
     * Método que muda a cor da carta
     * @param naipe
     */
    @Override
    public abstract CorCarta setCor(NaipeCarta naipe);
    
}
