/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import pt.ips.pa.model.tads.ModeloCarta.CorCarta;
import pt.ips.pa.model.tads.ModeloCarta.FiguraCarta;
import pt.ips.pa.model.tads.ModeloCarta.ValorCarta;
import pt.ips.pa.model.tads.ModeloCarta.NaipeCarta;
import Interface.InterfaceCarta;
import javax.swing.JComponent;

/**
 *
 * @author AnTRaX
 */
public final class CartaSolitaire extends JComponent implements InterfaceCarta {

    private CorCarta cor;
    private ValorCarta valor;
    private NaipeCarta naipe;
    private FiguraCarta figura;
    private boolean isVirada = false;

    /**
     * Construtor da Carta Solitaire
     * @param figura
     * @param naipe 
     */
    public CartaSolitaire(FiguraCarta figura,NaipeCarta naipe) {
        this.naipe = naipe;
        setValor(figura);
        getCor(naipe);
    }
    
    public CartaSolitaire CartaSolitaireClone(){
        return new CartaSolitaire(this.getFigura(), this.getNaipe());
    }

    /**
     * Método que obtém a cor da carta
     * @param naipe
     * @return cor
     */
    public CorCarta getCor(NaipeCarta naipe) {
        if (naipe == NaipeCarta.ESPADAS || naipe == NaipeCarta.PAUS) {
            cor = CorCarta.PRETO;
        }

        if (naipe == NaipeCarta.COPAS || naipe == NaipeCarta.OUROS) {
            cor = CorCarta.VERMELHO;
        }
        return cor;
    }

    /**
     * Método que obtém valor da carta
     * @return valor da carta
     */
    public ValorCarta getValor() {
        return valor;
    }
    
     @Override
    public void setFigura(FiguraCarta figura) {
        this.figura=figura;
    }

    public void setValor(FiguraCarta figura) {
        if (figura == FiguraCarta.AS) {
            valor = ValorCarta.UM;
        }

        if (figura == FiguraCarta.DOIS) {
            valor = ValorCarta.DOIS;
        }

        if (figura == FiguraCarta.TRES) {
            valor = ValorCarta.TRES;
        }

        if (figura == FiguraCarta.QUATRO) {
            valor = ValorCarta.QUATRO;
        }

        if (figura == FiguraCarta.CINCO) {
            valor = ValorCarta.CINCO;
        }

        if (figura == FiguraCarta.SEIS) {
            valor = ValorCarta.SEIS;
        }

        if (figura == FiguraCarta.SETE) {
            valor = ValorCarta.SETE;
        }

        if (figura == FiguraCarta.OITO) {
            valor = ValorCarta.OITO;
        }

        if (figura == FiguraCarta.NOVE) {
            valor = ValorCarta.NOVE;
        }

        if (figura == FiguraCarta.DEZ) {
            valor = ValorCarta.DEZ;
        }

        if (figura == FiguraCarta.VALETE) {
            valor = ValorCarta.UM;
        }

        if (figura == FiguraCarta.VALETE) {
            valor = ValorCarta.ONZE;
        }

        if (figura == FiguraCarta.DAMA) {
            valor = ValorCarta.DOZE;
        }

        if (figura == FiguraCarta.REI) {
            valor = ValorCarta.TREZE;
        }
    }

    /**
     * Método que retorna a figura da carta
     * @return getFigura da classe herdada (Carta)
     */
    @Override
    public FiguraCarta getFigura() {
        return figura;

    }

    /**
     * Método que retorna naipe da carta
     * @return naipe
     */
    public NaipeCarta getNaipe() {
        return naipe;
    }

    public void setNaipe(NaipeCarta naipe) {
        this.naipe = naipe;
    }
    
    public boolean isVirada() {
     return this.isVirada;
   }

    @Override
    public String toString() {

        return getFigura() + " de " + naipe;
    }

    @Override
    public CorCarta getCor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CorCarta setCor(NaipeCarta naipe) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

    
}
