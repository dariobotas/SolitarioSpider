/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import TADS.ListaDinamica;
import pt.ips.pa.model.tads.ModeloCarta.TipoEstrategia;

/**
 *
 * @author dario
 */
public class RunSolitaire {
    
    private int tempoJogo;
//    private boolean comecouJogo=true;
//    private boolean acabouJogo=false;
    private MonteDeCartas[] monteCartas;
    private BaralhoSolitaireFX baralho;
    private Jogador jogador;
    private PontuacaoNormal pontuacaoNormal;
    private PontuacaoInfantil pontuacaoInfantil;
    private ListaDinamica tabuleiro;
    private SolitaireCareTaker careTaker;
    
public RunSolitaire (Jogador jogador, String gameName) {
        tipoTabuleiro(gameName);
        
        baralho=new BaralhoSolitaireFX(null, null);
        careTaker = new SolitaireCareTaker();
        monteCartas=null;
}

private void tipoTabuleiro(String gameName){
        switch (gameName) {
            case "Infantil":
                tabuleiro = new ListaDinamica();
                tabuleiro.add(0, new MonteDeCartasSaiTres<>());
                tabuleiro.add(1, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(2, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(3, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(4, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(5, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(6, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(7, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(8, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(9, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(10, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                tabuleiro.add(11, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTECORIGUAL));
                pontuacaoInfantil.calcularPontos(0, 0, 0, 0);
                break;
            case "Normal":
                tabuleiro = new ListaDinamica();
                tabuleiro.add(0, new MonteDeCartasSaiTres<>());
                tabuleiro.add(1, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(2, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(3, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(4, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
                tabuleiro.add(5, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(6, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(7, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(8, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(9, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(10, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                tabuleiro.add(11, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
                pontuacaoNormal.calcularPontos(0, 0, 0, 0);
                break;
        }
    }
    
    public MonteDeCartas[] getMonteCartas() {
        return monteCartas;
    }

    public int getTempoJogo() {
        return tempoJogo;
    }

//    public boolean isComecouJogo() {
//        return comecouJogo;
//    }
//
//    public boolean isAcabouJogo() {
//        return acabouJogo;
//    }

public MementoSolitaire save() {
return new MementoSolitaire(tempoJogo);
}

public void restore(Object objMemento) {
MementoSolitaire memento = (MementoSolitaire)objMemento;
/*this.monteCartas = memento.getMementoMonteCartas();
this.comecouJogo=memento.isMementoComecouJogo();
this.acabouJogo=memento.isMementoAcabouJogo();
this.tempoJogo=memento.getMementoTempoJogo();*/
}
}
