/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

/**
 *
 * @author dario
 */
public class MementoSolitaire {
    
    private Jogo jogoAtual;
/*    private int tempoJogo;
    private boolean comecouJogo=true;
    private boolean acabouJogo=false;
    private MonteDeCartas monteCartas;
    private ListaDinamica tabuleiro;
    private SolitaireCareTaker careTaker;*/

    public MementoSolitaire(int gameName) {
        jogoAtual=new Jogo(gameName);
        
        //mementoTipoJogo(gameName);
        
        /*tabuleiro = new ListaDinamica();
        
        tabuleiro.add(0, new MonteDeCartasSaiTres<>());
        
        tabuleiro.add(1, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(2, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(3, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(4, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        
        tabuleiro.add(5, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(6, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(7, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(8, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(9, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(10, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(11, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        
        careTaker = new SolitaireCareTaker();
        monteCartas=null;*/
    }
    
    /*private void mementoTipoJogo(int gameName){
        if (gameName==1){
        tabuleiro = new ListaDinamica();
        
        tabuleiro.add(0, new MonteDeCartasSaiTres<>());
        
        tabuleiro.add(1, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(2, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(3, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(4, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        
        tabuleiro.add(5, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(6, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(7, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(8, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(9, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(10, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(11, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        
        }
        
        else if(gameName==2){
            tabuleiro = new ListaDinamica();
        
        tabuleiro.add(0, new MonteDeCartasSaiTres<>());
        
        tabuleiro.add(1, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(2, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(3, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        tabuleiro.add(4, new MonteDeCartasSequencial<>(TipoEstrategia.ASCENDENTE));
        
        tabuleiro.add(5, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(6, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(7, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(8, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(9, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(10, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        tabuleiro.add(11, new MonteDeCartasSequencial<>(TipoEstrategia.DESCENDENTE));
        }
    }*/
    
/*    public MonteDeCartas getMementoMonteCartas() {
        return monteCartas;
    }

    public void setMementoMonteCartas(MonteDeCartas monteCartas) {
        this.monteCartas = monteCartas;
    }

    public int getMementoTempoJogo() {
        return tempoJogo;
    }

    public boolean isMementoComecouJogo() {
        return comecouJogo;
    }

    public boolean isMementoAcabouJogo() {
        return acabouJogo;
    }*/

    public Jogo getMementoJogoAtual() {
        return jogoAtual;
    }

    public void setMementoJogoAtual(Jogo jogoAtual) {
        this.jogoAtual = jogoAtual;
    }
    
    
    
    
    
}
