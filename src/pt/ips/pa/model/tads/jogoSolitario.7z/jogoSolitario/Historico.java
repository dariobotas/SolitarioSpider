/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import Interface.InterfaceHistorico;
import TADS.QueueArray;
import java.util.*;

/**
 *
 * @author AnTRaX
 * @param <J>
 */
public class Historico<J extends Jogador> implements InterfaceHistorico {

    Date data;
    private QueueArray<J> adaptee;

    /**
     * 
     * @param player
     * @param game 
     */
    public Historico(J player, Jogo game) {
        adaptee = new QueueArray<>();
        data = new Date();
    }

    /**
     * 
     * @return 
     */
    @Override
    public int size() {
        return adaptee.size();
    }

    /**
     * 
     * @param elemento 
     */
    @Override
    public void adicionar(Object elemento) {
        if (isFull()) {
            remover();
            adaptee.enQueue((J) elemento);
        } else {
            adaptee.enQueue((J) elemento);
        }
    }
    
    /**
     * 
     */
    private void remover() {
        adaptee.deQueue();
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isFull() {
        return adaptee.isFull();
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isEmpty() {
        return adaptee.isEmpty();
    }

}
