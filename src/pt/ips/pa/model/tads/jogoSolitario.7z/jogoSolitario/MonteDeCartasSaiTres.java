/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import TADS.StackEstatica;
import Excecoes.MonteDeCartasCheioException;
import Excecoes.MonteDeCartasVazioException;
import Interface.InterfaceMonteDeCartas;
import Interface.Iterator;
import TADS.ListaDinamica;
import java.util.ArrayList;

/**
 *
 * @author dario
 * @param <C>
 */
public class MonteDeCartasSaiTres <C extends CartaSolitaireFX> extends MonteDeCartas<C> implements InterfaceMonteDeCartas<C> {
    //TEMOS DE ALTERAR A ESTRUTURA DESTA CLASSE PARA DE UM MONTE CRIAR 2 MAS SENDO SEMPRE O MESMO, O TAL MONTE DE LIXO QUE A PROF PATRICIA DISSE PARA NÃO SE USAR
    private final StackEstatica<C> adapt;
    private final StackEstatica<C> monteLixo;
    private static final int CAPACIDADE = 24;
    private ListaDinamica<C> cartas = new ListaDinamica<>();

    /**
     * 
     */
    public MonteDeCartasSaiTres() {
        adapt = new StackEstatica<>(CAPACIDADE);
        monteLixo = new StackEstatica<>(CAPACIDADE);
    } 
    
    public StackEstatica<C> getMonteLixo(){
        return this.monteLixo;
    }
    
    /**
     * 
     * @return 
     */
    @Override
    public int size(){
    return adapt.size();
    }

    /**
     * 
     * @param elemento
     * @throws MonteDeCartasCheioException 
     */
    @Override
    public void inserirNovaCarta(C elemento) throws MonteDeCartasCheioException {
    adapt.push(elemento);
    }

    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public C removeCarta() throws MonteDeCartasVazioException {
    return adapt.pop();
    }

    /*public C removeTresCarta() throws MonteDeCartasVazioException {
    return adapt.popTres();
    }*/
    
    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public C verCartaTopo() throws MonteDeCartasVazioException {
        return adapt.peek();
    }
    
//    public C verTresCartasTopo() throws MonteDeCartasVazioException{
//        return adapt.peekTres();
//    }

    /**
     * 
     * @return 
     */
   @Override
    public boolean isEmpty() {
        return adapt.isEmpty();
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isFull() {
        return adapt.isFull();
    }
    
    /**
     * 
     * @return 
     */
    public String verTresCartas(){
    String aux = "";
    for(int i = 0; i < 3; i++){
    aux += verCartaTopo().toString() + " \n ";
    removeCarta();
    //adapt.pop().toString();
    }
        return aux;
    }
    
    @Override
    public ListaDinamica<C> getCartasDisponiveis(CartaSolitaireFX carta) {
        ListaDinamica lis = new ListaDinamica();
        if(!carta.isVirada())
            return null;
        int cartaIndex = this.cartas.lastIndexOf(carta);
        
        if(cartaIndex>-1){
            for (int i= 0; i<this.cartas.size()-cartaIndex;i++)
            lis.add(cartaIndex, i);
        }
        return lis;
        
    }

    @Override
    public Object[] getArrayCards() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private class MonteDeCartasSaiTresIterator implements Iterator<C>{

        private final Iterator<C> itr;
        
        public MonteDeCartasSaiTresIterator(){
            itr = adapt.getIterator();
        }
        
        @Override
        public C next() {
            if(itr.hasNext()){
            return itr.next(); 
        }else{
                return null;
            }          
        }

        @Override
        public boolean hasNext() {
            return itr.hasNext();
        }

        
    }
}
