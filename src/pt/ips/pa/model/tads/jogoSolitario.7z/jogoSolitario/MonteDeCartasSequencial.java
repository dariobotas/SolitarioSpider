/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import Excecoes.MonteDeCartasVazioException;
import Interface.InterfaceMonteDeCartas;
import Interface.Iterator;
import TADS.ListaDinamica;
import TADS.StackEstatica;
import java.util.ArrayList;
import pt.ips.pa.model.tads.ModeloCarta.TipoEstrategia;
import pt.ips.pa.model.tads.estrategia.EstrategiaDeOrdenacao;
import pt.ips.pa.model.tads.estrategia.EstrategiaToDown;
import pt.ips.pa.model.tads.estrategia.EstrategiaToDownCorIgual;
import pt.ips.pa.model.tads.estrategia.EstrategiaToTop;

/**
 *
 * @author AnTRaX
 * @param <C>
 */
public class MonteDeCartasSequencial<C extends CartaSolitaireFX> extends MonteDeCartas<C> implements InterfaceMonteDeCartas<C> {

    private final StackEstatica<C> adaptee;
    private EstrategiaDeOrdenacao ordenar;
    private String estrategia;
    private static final int CAPACIDADE_DO_MONTE = 13;
    private TipoEstrategia typeStrategy;
    private ArrayList<C> cards;
    
    public MonteDeCartasSequencial(){
    adaptee = new StackEstatica<>(CAPACIDADE_DO_MONTE);
    }

    public MonteDeCartasSequencial(TipoEstrategia estrategia) {

        if (estrategia.equals(TipoEstrategia.ASCENDENTE)) {
            this.ordenar = new EstrategiaToTop();
            this.estrategia = "Ascendente";
        } else if (estrategia.equals(TipoEstrategia.DESCENDENTE)) {
            this.ordenar = new EstrategiaToDown();
            this.estrategia = "Descendente";
        } else if(estrategia.equals(TipoEstrategia.DESCENDENTECORIGUAL)){
            this.ordenar = new EstrategiaToDownCorIgual();
            this.estrategia = "Descendente por cores iguais";
        }
        adaptee = new StackEstatica<>(CAPACIDADE_DO_MONTE);
    }
    
/*    public MonteDeCartasSequencial(TipoEstrategia estrategia) {

        if (estrategia.equals(TipoEstrategia.ASCENDENTE)) {
            this.ordenar = new EstrategiaToTop();
            this.estrategia = "Ascendente";
        } else if (estrategia.equals(TipoEstrategia.DESCENDENTE)) {
            this.ordenar = new EstrategiaToDownCorIgual();
            this.estrategia = "Descendente";
        }
        adaptee = new StackEstatica<>(CAPACIDADE_DO_MONTE);
    }*/

    @Override
    public int size() {
        return adaptee.size();
    }

    @Override
    public boolean isEmpty() {
        return adaptee.isEmpty();
    }

    @Override
    public void inserirNovaCarta(C elemento) {
        adaptee.push(elemento);
    }

    @Override
    public C removeCarta() {
        return adaptee.pop();
    }

    @Override
    public Object[] getArrayCards() {
        return adaptee.getLista();
    }

    public void inserirNovaCarta(MonteDeCartasSequencial elemento) {
        switch (this.estrategia) {
            case "Ascendente":
                if (ordenar.isOrdenado(this, elemento)) {
                    this.inserirNovaCarta((C) elemento.removeCarta());
                }   break;
            case "Descendente":
                if (ordenar.isOrdenado(this, elemento)) {
                    for (int i = 0; i < elemento.size(); i++) {
                        MonteDeCartasSequencial aux = new MonteDeCartasSequencial();
                        aux.inserirNovaCarta((CartaSolitaireFX) elemento.getArrayCards()[i]);
                        
                        for (int x = 0; x < aux.size(); x++) {
                            this.inserirNovaCarta((C) aux.getArrayCards()[x]);
                        }
                    }
                }   break;
            case "Descendente por cores iguais":
                if (ordenar.isOrdenado(this, elemento)) {
                    for (int i = 0; i < elemento.size(); i++) {
                        MonteDeCartasSequencial aux = new MonteDeCartasSequencial();
                        aux.inserirNovaCarta((CartaSolitaireFX) elemento.getArrayCards()[i]);
                        
                        for (int x = 0; x < aux.size(); x++) {
                            this.inserirNovaCarta((C) aux.getArrayCards()[x]);
                        }
                    }
                }   break;
        }
    }

    public void removerCartas(MonteDeCartasSequencial elementos) {
        if (isEmpty()) {
            //Falta lançar excepção... Talvez diretamente da interface
        } else {
            switch (this.estrategia) {
                case "Ascendente":
                    elementos.inserirNovaCarta(this.removeCarta());
                    break;
                case "Descendente":
                    if (ordenar.isOrdenado(elementos, this)) {
                        for (int i = 0; i < this.size(); i++) {
                            MonteDeCartasSequencial aux = new MonteDeCartasSequencial();
                            aux.inserirNovaCarta((CartaSolitaireFX) this.getArrayCards()[i]);
                            
                            for (int x = 0; x < aux.size(); x++) {
                                elementos.inserirNovaCarta((C) aux.getArrayCards()[x]);
                            }
                        }
                    }   break;
                case "Descendente por cores iguais":
                    if (ordenar.isOrdenado(elementos, this)) {
                        for (int i = 0; i < this.size(); i++) {
                            MonteDeCartasSequencial aux = new MonteDeCartasSequencial();
                            aux.inserirNovaCarta((CartaSolitaireFX) this.getArrayCards()[i]);
                            
                            for (int x = 0; x < aux.size(); x++) {
                                elementos.inserirNovaCarta((C) aux.getArrayCards()[x]);
                            }
                        }
                    }   break;
            }
        }
    }

    @Override
    public C verCartaTopo() throws MonteDeCartasVazioException{
        return adaptee.peek();
    }

    public void mostraCartas() {
        Iterator<C> it = this.getIterator();
        do {
            System.out.println(it.next());
        } while (it.hasNext());
    }
    
    public ListaDinamica<C> getCartasDisponiveis(CartaSolitaireFX card){
    ListaDinamica ret = new ListaDinamica();
 
     if (!card.isVirada()) {
       return null;
    }
 
     int cardIdx = this.cards.lastIndexOf(card);
 
     if (cardIdx > -1) {
       for (int i = 0; i < this.cards.size() - cardIdx; i++) {
         ret.add(i,this.cards.get(cardIdx + i));
       }

     }return ret;
    }

    @Override
    public Iterator<C> getIterator() {
        return new IterarMonteSequencial();
    }

    public class IterarMonteSequencial implements Iterator<C> {

        private final Iterator<C> it;

        public IterarMonteSequencial() {
            it = adaptee.getIterator();
        }

        @Override
        public C next() {
            if (it.hasNext()) {
                return it.next();
            } else {
                return null;
            }
        }

        @Override
        public boolean hasNext() {
            return it.hasNext();
        }
    }
}
