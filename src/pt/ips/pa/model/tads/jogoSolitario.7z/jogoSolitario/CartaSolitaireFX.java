/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import utilities.VolatileImageLoader;
import pt.ips.pa.model.tads.ModeloCarta.CorCarta;
import pt.ips.pa.model.tads.ModeloCarta.FiguraCarta;
import pt.ips.pa.model.tads.ModeloCarta.ValorCarta;
import pt.ips.pa.model.tads.ModeloCarta.NaipeCarta;
import Interface.InterfaceCarta;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.VolatileImage;
import java.io.IOException;

/**
 *
 * @author AnTRaX
 */
public final class CartaSolitaireFX extends Carta implements InterfaceCarta {

    private FiguraCarta figura;
    private String tipo;
    private CorCarta cor;
    private ValorCarta valor;
    private NaipeCarta naipe;
    private BufferedImage trasImage;
    private BufferedImage imagem;
    private BufferedImage viradaImagem;
    private BufferedImage sobreImagem;
    private int l;
    private int a;
    private int largura;
    private int altura;
    private int valorCarta;
    private boolean estaVirada = false;
   private boolean RESSALTAR = false;
 
  private VolatileImage vimage = null;
   private VolatileImage trasVimImage = null;
   private VolatileImage viradaVimImage = null;
   private VolatileImage sobreAVimImage = null;

    /**
     * Construtor da Carta Solitaire
     * @param figura
     * @param naipe 
     */
    public CartaSolitaireFX(FiguraCarta figura,NaipeCarta naipe) {
        super(figura);
        this.naipe = naipe;
        setValor(figura);
        getCor(naipe);
    }
    
    public CartaSolitaireFX(String figura, int valorCarta, BufferedImage backImage, BufferedImage turnedImage, BufferedImage overImage, int w, int h) {
        super(null);
        this.tipo=figura;
        this.valorCarta = valorCarta;
        this.trasImage = backImage;
        this.imagem = backImage;
        this.viradaImagem = turnedImage;
        this.sobreImagem = overImage;
        this.l = w;
        this.a = h;
        try {
            this.trasVimImage = VolatileImageLoader.loadFromBufferedImage(backImage, 3);

            this.vimage = VolatileImageLoader.loadFromBufferedImage(backImage, 3);

            this.viradaVimImage = VolatileImageLoader.loadFromBufferedImage(turnedImage, 3);

            this.sobreAVimImage = VolatileImageLoader.loadFromBufferedImage(overImage, 3);
        } catch (IOException ioe) {
            System.err.println("Could not convert from BufferedImage to VolatileImage");
        }
    }

    public CartaSolitaireFX cartaClone(){
    return new CartaSolitaireFX(this.tipo, this.valorCarta, this.trasImage, this.viradaImagem, this.sobreImagem, this.l, this.a);
    }
    
    public void virarCarta(){
    this.estaVirada = true;
    this.vimage = this.viradaVimImage;
    }
    
    public void esconderCarta(){
    this.estaVirada = false;
    this.vimage = this.trasVimImage;
    }
    
    public void highLight(Boolean bool){
    if(bool){
    this.vimage = this.sobreAVimImage;
    this.RESSALTAR = true;
    }
    if(!bool){
    this.vimage = this.viradaVimImage;
    this.RESSALTAR = false;
    }
    repaint(1);
    }
    
    public boolean isRessaltado(){
    return this.RESSALTAR;
    }
    
    public boolean isVirada(){
    return this.estaVirada;
    }
    
    @Override
    public String getName(){
    if(this.valor.valorCarta == 1) return "AS";
    if(this.valor.valorCarta == 13) return "Rei";
    if(this.valor.valorCarta == 12) return "Rainha";
    if(this.valor.valorCarta == 11) return "Valete";
    return "" + this.valor.valorCarta;
    }
    
    public int getValorInteger(){
    return this.valor.valorCarta;
    }
    
    public String nomeValor(){
    return getName() + " " + this.valor.valorCarta;
    }
    
    @Override
    protected void paintComponent(Graphics graphics){
    Graphics g = graphics.create();
    g.drawImage(this.vimage, 0, 0, null);
    g.dispose();
    }
    
    /**
     * Método que obtém a cor da carta
     * @param naipe
     * @return cor
     */
    public CorCarta getCor(NaipeCarta naipe) {
        if (naipe == NaipeCarta.ESPADAS || naipe == NaipeCarta.PAUS) {
            cor = CorCarta.PRETO;
        }

        if (naipe == NaipeCarta.COPAS || naipe == NaipeCarta.OUROS) {
            cor = CorCarta.VERMELHO;
        }
        return cor;
    }

    /**
     * Método que obtém valor da carta
     * @return valor da carta
     */
    public ValorCarta getValor() {
        return valor;
    }
    
     @Override
    public void setFigura(FiguraCarta figura) {
        this.figura = figura;
    }

    public void setValor(FiguraCarta figura) {
        if (figura == FiguraCarta.AS) {
            valor = ValorCarta.UM;
        }

        if (figura == FiguraCarta.DOIS) {
            valor = ValorCarta.DOIS;
        }

        if (figura == FiguraCarta.TRES) {
            valor = ValorCarta.TRES;
        }

        if (figura == FiguraCarta.QUATRO) {
            valor = ValorCarta.QUATRO;
        }

        if (figura == FiguraCarta.CINCO) {
            valor = ValorCarta.CINCO;
        }

        if (figura == FiguraCarta.SEIS) {
            valor = ValorCarta.SEIS;
        }

        if (figura == FiguraCarta.SETE) {
            valor = ValorCarta.SETE;
        }

        if (figura == FiguraCarta.OITO) {
            valor = ValorCarta.OITO;
        }

        if (figura == FiguraCarta.NOVE) {
            valor = ValorCarta.NOVE;
        }

        if (figura == FiguraCarta.DEZ) {
            valor = ValorCarta.DEZ;
        }

        if (figura == FiguraCarta.VALETE) {
            valor = ValorCarta.UM;
        }

        if (figura == FiguraCarta.VALETE) {
            valor = ValorCarta.ONZE;
        }

        if (figura == FiguraCarta.DAMA) {
            valor = ValorCarta.DOZE;
        }

        if (figura == FiguraCarta.REI) {
            valor = ValorCarta.TREZE;
        }
    }

    /**
     * Método que retorna a figura da carta
     * @return getFigura da classe herdada (Carta)
     */
    @Override
    public FiguraCarta getFigura() {
        return this.figura;

    }

    /**
     * Método que retorna naipe da carta
     * @return naipe
     */
    public NaipeCarta getNaipe() {
        return naipe;
    }

    public void setNaipe(NaipeCarta naipe) {
        this.naipe = naipe;
    }

    @Override
    public String toString() {

        return this.figura + " de " + naipe;
    }

    @Override
    public CorCarta getCor() {
        return this.cor;
    }

    @Override
    public CorCarta setCor(NaipeCarta naipe) {
        if (naipe.equals(NaipeCarta.COPAS) || naipe.equals(NaipeCarta.OUROS))
            return this.cor=CorCarta.VERMELHO;
        else 
             return this.cor=CorCarta.PRETO;
        
    }

    
    
}
