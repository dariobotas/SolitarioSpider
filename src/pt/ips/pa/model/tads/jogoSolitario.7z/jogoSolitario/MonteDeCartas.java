/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import TADS.StackEstatica;
import Excecoes.MonteDeCartasCheioException;
import Excecoes.MonteDeCartasVazioException;
import Interface.InterfaceMonteDeCartas;
import Interface.Iterator;
import TADS.ListaDinamica;
import java.awt.Point;
import java.util.Observable;

/**
 *
 * @author AnTRaX
 * @param <C>
 */
public abstract class MonteDeCartas<C extends CartaSolitaireFX> extends Observable implements InterfaceMonteDeCartas<C>{

    
    private final StackEstatica<C> adapt;
    private static final int SIZE=24;
    int x,y;

    /**
     *
     * @param card
     * @return
     */
    public abstract ListaDinamica<C> getCartasDisponiveis(CartaSolitaireFX card);
    
    /**
     * 
     */
    public MonteDeCartas() {
        adapt = new StackEstatica<>(SIZE);
    }
    
    /**
     * 
     * @return 
     */
    public StackEstatica<C> getAdapt(){
    return this.adapt;
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isEmpty() {
        return adapt.isEmpty();
    }

    /**
     * 
     * @param elemento
     * @throws MonteDeCartasCheioException 
     */
    @Override
    public void inserirNovaCarta(C elemento) throws MonteDeCartasCheioException {
         if(isFull()){
        throw new MonteDeCartasCheioException("Monte Cheio");
        }
        else{
        adapt.push(elemento);
        setChanged();
        notifyObservers();
        }
    }

    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public C removeCarta() throws MonteDeCartasVazioException {
        if(isEmpty()){
        throw new MonteDeCartasVazioException("Monte Vazio");
        }
        else{
        
        setChanged();
        notifyObservers();
        
        return adapt.pop();
        }
    }
    
    public void escondeCartas(ListaDinamica<CartaSolitaireFX> cards)   {
     for (int i=0; i<cards.size();i++)
       removeCarta();
   }

    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public C verCartaTopo() throws MonteDeCartasVazioException {
        if(isEmpty()){
        throw new MonteDeCartasVazioException("Monte Vazio");
        }
        else{
            C elemento = adapt.peek();
            adapt.push(elemento);
        return elemento;
        }
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isFull() {
        return adapt.isFull();
    }

    /**
     * 
     * @return 
     */
    @Override
    public int size() {
        return adapt.size();
    }
    
    public abstract Object[] getArrayCards();
    
    public final void transporta(Point pp, Point p)  {
     setLocation(pp.x - p.x, pp.y - p.y);
   }
    
    /**
     * 
     * @return 
     */
    @Override
    public String toString(){
    
         String baralho = "Monte de Cartas: ";
        
         return baralho;
    }
    
    @Override
    public Iterator getIterator(){
        return new MonteDeCartasIterator();
    }

    private void setLocation(int i, int i0) {
        x=i; y=i0;
    }
    
    private class MonteDeCartasIterator implements Iterator<C>{

        private final Iterator<C> itr;
        
        public MonteDeCartasIterator(){
            itr = adapt.getIterator();
        }
        
        @Override
        public C next() {
            if(itr.hasNext()){
            return itr.next(); 
        }else{
                return null;
            }          
        }

        @Override
        public boolean hasNext() {
            return itr.hasNext();
        }

        
    }
    
}
