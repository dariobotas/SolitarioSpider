/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import java.util.*;
import pt.ips.pa.model.tads.estrategia.EstrategiaPontos;

/**
 *
 * @author dario
 */
public final class Jogador {

    private static Jogador instance;
    private String logID;
    private final Date data;
    private int pontosAcumulados;
    private final EstrategiaPontos pontos;

    /**
     * Construtor do Jogador
     * @param logID 
     * @param pontos  
     */
    public Jogador(String logID, EstrategiaPontos pontos) {
        this.logID = logID;
        this.pontos = pontos;
        this.data = new Date();
    }
    
    public static Jogador Instance(){
        if(instance == null){
            instance= new Jogador(null, null);
        }
        return instance;
    }

    /**
     * Método que mostra o nome do jogador
     * @return logID
     */
    public String getNick() {
        return logID;
    }

    /**
     * Método que altera o nome do jogador
     * @param logID  
     */
    public void setNick(String logID) {
        this.logID = logID;
    }

    
    public void pontuacaoAcumulada(int moveColuna, int moveNaipe, int sequencia) {
        pontosAcumulados += pontos.calcularPontos(moveColuna, moveNaipe, sequencia);
    }

    public int getPontosAcumulados() {
        return this.pontosAcumulados;
    }

    public void resetPontuacao() {
        pontosAcumulados = 0;
    }

    @Override
    public String toString() {
        return "(" + data + ")"+ " Player--> " + logID + " possui " + pontosAcumulados + " pontos.";
    }

}
