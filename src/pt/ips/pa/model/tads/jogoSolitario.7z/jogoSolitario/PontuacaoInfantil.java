/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

/**
 *
 * @author AnTRaX
 */
public class PontuacaoInfantil implements Interface.InterfacePontuacao{

    /**
     * 
     * @param moveCarta Indica a carta que é movida do baralho para uma coluna
     * @param moveParaMonteNaipe Indica a carta que é movida para o monte especifico do naipe
     * @param casaNaipeCompleta Indica o numero de montes de naipes especificos (de 1 a 4) já completos
     * @param time Indica o tempo total do jogo
     * @return 
     */
    @Override
    public int calcularPontos(int moveCarta, int moveParaMonteNaipe, int casaNaipeCompleta, int time) {
        if(casaNaipeCompleta == 4){
        return(moveCarta * 5) + (moveParaMonteNaipe * 10) + (700000 / time);
        }
        return (moveCarta * 5) + (moveParaMonteNaipe * 10);
    }
    
    
}
