/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;
import pt.ips.pa.model.tads.estrategia.EstrategiaPontos;
/**
 *
 * @author AnTRaX
 */
public class Jogo {
    
    private String nomeJogo;
    private EstrategiaPontos pontos;
    private SolitaireCareTaker solitaireInfoCareTaker;
    
    public Jogo(int gameName){
        if (gameName==1){
            this.nomeJogo="Versão Infantil";
            
        }
        if(gameName==2){
            this.nomeJogo="Versão Mão de Três";
            
        }
    }
    
    
    
    
    @Override
    public String toString(){
    return "Está a jogar: " + nomeJogo;
    }
}
