/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import TADS.*;
import java.util.Observable;

/**
 *
 * @author dario
 */
public class SolitaireCareTaker extends Observable{
    
    private StackDinamica<MementoSolitaire> stackMementoUndo; //multi- undo

    public SolitaireCareTaker() {
    stackMementoUndo = new StackDinamica();
    }
    
    public void saveState(RunSolitaire solitaireInfo) {
        MementoSolitaire objMemento = solitaireInfo.save();
        stackMementoUndo.push(objMemento);

 }

 public void restoreState(RunSolitaire solitaireInfo) {
    if (!stackMementoUndo.isEmpty()) {
        MementoSolitaire objMemento = stackMementoUndo.pop();
    solitaireInfo.restore(objMemento);
    }
 }
    
}
