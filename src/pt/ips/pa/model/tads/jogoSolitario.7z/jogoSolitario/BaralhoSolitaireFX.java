/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import Excecoes.MonteDeCartasLimiteAtingido;
import TADS.ListaDinamica;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JLabel;
import utilities.CardImageMaker;
import utilities.LayoutVariables;

/**
 * 
 * @author AnTRaX
 */
public class BaralhoSolitaireFX<C extends CartaSolitaireFX> extends JLabel implements Serializable {

    private CardImageMaker cim;
    private CardImageMaker cim2;
    private final String[] types = {"copas", "paus", "ouros", "espadas"};
    private CartaSolitaireFX[][] deck = new CartaSolitaireFX[4][13];
    private ListaDinamica<CartaSolitaireFX> deckArrayList = new ListaDinamica();
    private final int CARTA_LARGURA = 79;
    private final int CARTA_ALTURA = 123;
    private final int ESPACAMENTO_STACK = 20;

    private int idx = 0;

    private boolean IS_EMPTY = false;

    /**
     * 
     * @param cim
     * @param cim2 
     */
    public BaralhoSolitaireFX(CardImageMaker cim, CardImageMaker cim2) {
        setBackground(null);
        setLayout(null);
        this.cim = cim;
        this.cim2 = cim2;
        BufferedImage image = cim.desenhaCarta("back", 2);

        String type = null;
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                type = "copas";
            }
            if (i == 1) {
                type = "paus";
            }
            if (i == 2) {
                type = "ouros";
            }
            if (i == 3) {
                type = "espadas";
            }
            for (int j = 0; j < 13; j++) {
                BufferedImage turnedImage = cim.desenhaCarta(type, j);
                BufferedImage overImage = cim2.desenhaCarta(type, j);
                this.deck[i][j] = new CartaSolitaireFX(this.types [i], j + 1, image, turnedImage, overImage, 79, 123);
            }

        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 13; j++) {
                this.deckArrayList.add(this.deck[i][j]);
            }

        }

        Collections.shuffle((List)this.deckArrayList);
    }

    /**
     * 
     * @return 
     */
    public boolean isEmpty() {
        return this.deckArrayList.isEmpty();
    }

    /**
     * 
     * @return 
     */
    
    public int tamanho(){
        return this.deckArrayList.size();
    }

    /**
     * 
     * @param idx
     * @return 
     */
    public CartaSolitaireFX getCartaPosicao(int idx) {
        return (CartaSolitaireFX) this.deckArrayList.get(idx);
    }

    /**
     * 
     * @param c 
     */
    public void removeCarta(CartaSolitaireFX c) {
        remove(c);
        this.deckArrayList.remove(c);
    }

    /**
     * 
     * @param c 
     */
    public void removeCartas(ArrayList<CartaSolitaireFX> c) {
        for (CartaSolitaireFX card : c) {
            this.deckArrayList.remove(card);
            remove(card);
            repaint();
        }
        if (this.idx > 0) {
            this.idx -= 1;
        }
    }
    
    /**
     * Método para remover um elemento duma posição.
     * @param idx
     * @return elemento removido
     * @throws MonteDeCartasLimiteAtingido 
     */
    public C remover(int idx) throws MonteDeCartasLimiteAtingido {
        if (idx < 0 || idx > this.deckArrayList.size()) {
            throw new MonteDeCartasLimiteAtingido("Carta fora de posição");
        }
        return (C) this.deckArrayList.remove(idx);

    }

    /**
     * 
     * @param cards 
     */
    public void addCartas(ArrayList<CartaSolitaireFX> cards) {
        for (CartaSolitaireFX card : cards) {
            this.deckArrayList.add(card);
        }
    }

    /**
     * 
     * @param cardCount
     * @return 
     */
    public ArrayList<CartaSolitaireFX> getCartas(int cardCount) {
        if (this.idx == 0) {
            showAsFull();
        }
        int i = 0;

        if (cardCount == 3) {
            if (this.idx <= this.deckArrayList.size() - 3) {
                i = 3;
            } else if (this.idx == this.deckArrayList.size() - 2) {
                i = 2;
            } else if (this.idx == this.deckArrayList.size() - 1) {
                i = 1;
            } else {
                return null;
            }
        } else {
            i = cardCount;
        }
        ArrayList ret = new ArrayList();

        for (int j = this.idx; j < this.idx + i; j++) {
            ret.add(this.deckArrayList.get(j));
        }
        this.idx += i;
        if (this.idx == this.deckArrayList.size()) {
            showAsEmpty();
            this.idx = 0;
        }
        return ret;
    }

    /**
     * 
     */
    public void showAsEmpty() {
        this.IS_EMPTY = true;
        repaint();
    }

    /**
     * 
     */
    public void showAsFull() {
        this.IS_EMPTY = false;
        repaint();
    }

    /**
     * 
     * @param graphics 
     */
    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D g = (Graphics2D) graphics.create();

        if (!this.IS_EMPTY) {
            BufferedImage image = this.cim.getCardBack();
            g.drawImage(image, 0, 0, null);
        } else {
            g.setColor(LayoutVariables.PLACEHOLDER_COLOR);
            g.setComposite(LayoutVariables.PLACEHOLDER_ALPHA);
            g.fillRect(0, 0, 79, 123);
        }

        g.dispose();
    }
}
