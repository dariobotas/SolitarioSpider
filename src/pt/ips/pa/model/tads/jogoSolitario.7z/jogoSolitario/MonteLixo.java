/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ips.pa.model.tads.jogoSolitario;

import TADS.ListaDinamica;
import TADS.StackDinamica;
import TADS.StackEstatica;

/**
 *
 * @author dario
 */
public class MonteLixo extends StackDinamica {

    private BaralhoSolitaireFX baralho;
    private ListaDinamica<CartaSolitaireFX> cartas = new ListaDinamica<>();
    
    public MonteLixo(BaralhoSolitaireFX baralho) {
        this.baralho=baralho;
    }
    
    @Override
    public boolean isEmpty(){
        return this.cartas.isEmpty();
    }
    
    public boolean isFull(){
        return this.cartas.size()==3;
    }
    
    @Override
    public int size(){
        return this.cartas.size();
    }
    
    public CartaSolitaireFX getCartaNoTopo(){
        return (CartaSolitaireFX)this.cartas.get(this.size()-1);
    }
    
    public ListaDinamica<CartaSolitaireFX> getCartasDisponiveis(CartaSolitaireFX carta) {
        ListaDinamica lista = new ListaDinamica();
        if(!carta.isVirada())
            return null;
        int cartaIndex = this.cartas.lastIndexOf(carta);
        
        if(cartaIndex>-1){
            for (int i= 0; i<this.cartas.size()-cartaIndex;i++)
            lista.add(cartaIndex, i);
        }
        return lista;
    }
    
    public void escondeCartas(ListaDinamica<CartaSolitaireFX> cartas)   {
     for (int i=0; i<cartas.size();i++)
       this.cartas.remove(cartas.get(0).getValorInteger());
   }
    
    public void mostrarCartas(ListaDinamica<CartaSolitaireFX> cartas){
        ((CartaSolitaireFX)cartas.get(0)).setLocation(this.cartas.size(), 0);
        push(cartas.get(0));
    }
    
    public void adicionarUmaCarta(CartaSolitaireFX carta){
        push(carta);
        for (int i=0; i<cartas.size();i++)
            this.cartas.add(i, carta);
    }
    
}
