/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TADS;

/**
 *
 * @author AnTRaX
 * @param <E>
 */
public class DNode<E> {
    
    private E elemento;
    private DNode<E> next;
    private DNode<E> prev;

    /**
     * 
     * @param elemento
     * @param next
     * @param prev 
     */
    public DNode(E elemento, DNode<E> next, DNode<E> prev) {
        this.elemento = elemento;
        this.next = next;
        this.prev = prev;
    }
    
    /**
     * 
     * @param elemento 
     */
    public DNode(E elemento){
    this.elemento = elemento;
        this.next = null;
        this.prev = null;
    }

    /**
     * 
     * @return 
     */
    public E getElemento() {
        return elemento;
    }

    /**
     * 
     * @param elemento 
     */
    public void setElemento(E elemento) {
        this.elemento = elemento;
    }

    /**
     * 
     * @return 
     */
    public DNode<E> getNext() {
        return next;
    }

    /**
     * 
     * @param next 
     */
    public void setNext(DNode<E> next) {
        this.next = next;
    }

    /**
     * 
     * @return 
     */
    public DNode<E> getPrev() {
        return prev;
    }

    /**
     * 
     * @param prev 
     */
    public void setPrev(DNode<E> prev) {
        this.prev = prev;
    }
    
}
