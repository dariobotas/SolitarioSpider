/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TADS;

import TADS.Node;
import Excecoes.MonteDeCartasCheioException;
import Excecoes.MonteDeCartasVazioException;
import Interface.InterfaceStack;

/**
 *
 * @author dario
 * @param <E>
 */
public class StackDinamica<E> implements InterfaceStack<E> {
    
    private Node<E> topo;
    private int size;

    public StackDinamica() {
    topo = null;
    size = 0;
    }

    /**
     * 
     * @return 
     */
    @Override
    public int size() {
   return size;
    }

    /**
     * 
     * @return 
     */
    @Override
    public boolean isEmpty() {
    return size == 0;
    }

    /**
     * 
     * @param elemento
     * @throws MonteDeCartasCheioException 
     */
    @Override
    public void push(E elemento) throws MonteDeCartasCheioException {
     Node aux = new Node(elemento, topo);
     topo = aux;
     size++;
    }

    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public E pop() throws MonteDeCartasVazioException {
     if(isEmpty())
         throw new MonteDeCartasVazioException("Monte de cartas Vazio");
     
     E elemento = peek();
     topo = topo.getNext();
     size--;
     return elemento;
    }

    /**
     * 
     * @return
     * @throws MonteDeCartasVazioException 
     */
    @Override
    public E peek() throws MonteDeCartasVazioException {
    if(isEmpty())
        throw new MonteDeCartasVazioException("Monte de Cartas Vazio");
    
    return topo.getElemento();
    }
}
